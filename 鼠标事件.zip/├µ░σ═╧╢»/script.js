//解决getElementsByClassNmae在IE浏览器不兼容问题：封装一个函数
function getClassName(clsname,parent){
	var oParent = parent?document.getElementById(parent):document,
	eles = [],
	elements = oParent.getElementsByTagName("*");
	for(var i = 0; i < elements.length; i++){
		if(elements[i].className == clsname){
			eles.push(elements[i]);
		}
	}
	return eles;
}

window.onload = drag;

function drag(){
	var otitle = getClassName("title","box_top")[0];
	//拖拽面板
	otitle.onmousedown = funDown;
	//关闭面板
	document.getElementById("box_close").onclick = function(){
		document.getElementById("box").style.display = "none";
	};
	//打开面板
	document.getElementsByTagName("button")[0].onclick = function(){
		document.getElementById("box").style.display = "block";
	};
	//选项栏
	document.getElementById("state").onclick = funSel;
	//由于事件冒泡所以上下两个事件之间需要取消冒泡
	document.onclick = function(){
		document.getElementsByTagName("ul")[0].style.display = "none";
	}
}

function funSel(e){
		if (e && e.stopPropagation) {
            e.stopPropagation();
        }
        else {
            window.event.cancelBubble = true;
        }
	var a = document.getElementsByTagName("ul")[0];
	a.style.display = "block";
	var b = a.getElementsByTagName("li");
	for(var i = 0; i < b.length; i++){
		b[i].onmouseover = function(){
			this.style.background = "red";
		}
		b[i].onmouseout = function(){
			this.style.background = "white";
		}
		b[i].onclick = function(){
			var d = document.getElementById("state");
			var g = d.firstChild;
			g.parentNode.removeChild(g);
			var e = this.firstChild;
			var h = e.cloneNode(true);
			d.appendChild(h);
			var f = d.firstChild.nodeValue;
			a.style.display = "none";
			return false;
		};
	}
}

function funDown(event){
	//解决浏览器兼容问题，若是IE浏览器则用window.event
	event = event || window.event;
	var oDrag = document.getElementById("box");
	//光标按下时光标和面板的距离
	disX = event.clientX - oDrag.offsetLeft;
	disY = event.clientY - oDrag.offsetTop;
	/*document.onmousemove = function(event){
		event = event || window.event;
		//document.title = event.clientX + "," + event.clientY;
		oDrag.style.left = event.clientX + "px";
		oDrag.style.top = event.clientY + "px";*/
	document.onmousemove = function(event){
		event = event || window.event;
		funMove(event,disX,disY);
	};
	document.onmouseup = function(){
		document.onmousemove = null;
		document.onmouseup = null;
	}
}

function funMove(e,posX,posY){
	var oDrag = document.getElementById("box"),
		//获取浏览器窗口宽度和高度，同时解决浏览器兼容问题
		winW = document.documentElement.clientWidth || document.body.clientWidth,
		winH = document.documentElement.clientHeight || document.body.clientHeight,
		//oDrag.offsetWidth获取面板宽度
		maxW = winW - oDrag.offsetWidth,
		maxH = winH - oDrag.offsetHeight,
		//e.clientX光标位置
		l = e.clientX - posX,
		t = e.clientY - posY;
	if(l < 0){
		l = 0;
	}else if(l > maxW){
		l = maxW;
	}
	if(t < 0){
		t = 0;
	}else if(t > maxH){
		t = maxH;
	}
	oDrag.style.left = l + "px";
	oDrag.style.top = t + "px";
	//document.title = l;
}